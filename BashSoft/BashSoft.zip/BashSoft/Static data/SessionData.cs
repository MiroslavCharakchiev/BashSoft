﻿
using System.IO;

namespace BashSoft
{
    public static class SessionData
    {
        public static string currentPath = Directory.GetCurrentDirectory();
    }
}
